public class a2 {
    public static void main(String[] args) {
        System.out.println("13 09 2022" + "\t Maksymilian Czajka" + "\tMalinowa 6" + "\t34245262346");
    }
}
