public class asdfghj {
    public static void main(String[] args) {
        String name = "Maks";
        String drug_imie= "Wiktor";
        String Nazwisko = "Czajka";
        char ab = name.charAt(1);
        char ba = drug_imie.charAt(1);
        char cd = Nazwisko.charAt(1);
        System.out.println(
                name+ "  " +drug_imie + "  "+Nazwisko+"  "
        );
        System.out.println(ab + ba + cd + "MWC");
    }
}
