public class asdfs{
    public static void main(String[] args) {
        System.out.println("Według mnie najlepsze gry to: ");
        System.out.println("\"Minecraft \" (bo napisany w Javie:)");
        System.out.println("\" WOT \"");
        System.out.print("\"CS 1.6\"");
        System.out.print("\"Dying Light\"");
        System.out.print("\"Najlepsze gry\"");
        System.out.print("\"DayZ\"");
        System.out.print("\"CSGO\"");
        }
    }

