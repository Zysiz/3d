public class asf {
    public static void main(String[] args) {
        System.out.print("  *");
        System.out.print("\n ***");
        System.out.print("\n*****");
        System.out.print("\n ***");
        System.out.print("\n  *");
    }
}
