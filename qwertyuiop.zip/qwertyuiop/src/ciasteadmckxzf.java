import java.util.Scanner;

public class ciasteadmckxzf {
    public static void main(String[] args) {
        Scanner klawiatura = new Scanner(System.in);
        double ciasteczka,kalorie,wynik;
        System.out.println("ile ciastek zjadles: ");
        ciasteczka = klawiatura.nextInt();
        klawiatura.nextLine();
        kalorie=30;
        wynik=ciasteczka*kalorie;
        System.out.println(wynik);

    }
}
