public class erty {
    public static void main(String[] args) {
    int room1,room2,room3,room4,calk,dlugosc,szerokosc,osoba,pownaos;


    dlugosc=2;
    szerokosc=2;
        room1= dlugosc * szerokosc;


        dlugosc=2;
        szerokosc=3;
        room2= dlugosc * szerokosc;

        dlugosc=3;
        szerokosc=4;
        room3= dlugosc * szerokosc;

        dlugosc=3;
        szerokosc=4;
        room4= dlugosc * szerokosc;

        calk= room1 + room2 + room3 + room4;

        osoba = 4;
        pownaos= calk / osoba;

        System.out.print(room1 + "  ");
        System.out.print(room2 + "   ");
        System.out.print(room3 + "   ");
        System.out.print(room4 + "    ");
        System.out.print(calk + "  ");
        System.out.print(pownaos);
    }
}
