public class gfhj {
    public static void main(String[] args) {
        double sprzedaz,dochod,mazowiecki;
        sprzedaz=4600000;
        dochod=0.62;
        mazowiecki =sprzedaz * dochod;
        System.out.println(mazowiecki);


    }
}
