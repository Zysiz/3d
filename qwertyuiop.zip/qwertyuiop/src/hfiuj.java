import java.util.Scanner;

public class hfiuj {
    public static void main(String[] args) {
        double koszt,lokal,stan;
        Scanner klawiatura = new Scanner(System.in);
        double cal;
        System.out.println("Podaj calkowity koszt produktu: ");
        cal = klawiatura.nextInt();
        klawiatura.nextLine();
        lokal=0.02;
        stan=0.04;
        koszt=(cal*(lokal+stan))+cal;
        System.out.println("koszt calego zamowienia       "+koszt);
        double stanowy,podloka;
        stanowy = cal*stan;
        System.out.println(stanowy+"    "+"podatek stanowy");
        podloka=cal * lokal;
        System.out.println(podloka+"    "+"podatek lokalny");
    }
}
