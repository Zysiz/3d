import java.util.Scanner;

public class hgkkjhy {
    public static void main(String[] args) {
        double kilometry , litry , kmnalitr;
        Scanner klawiatura = new Scanner(System.in);
        System.out.println("Przejechane kilometry: ");
        kilometry = klawiatura.nextInt();
        klawiatura.nextLine();


        Scanner klawiatura2 = new Scanner(System.in);
        System.out.println("Wypalone litry: ");
        litry = klawiatura2.nextInt();
        klawiatura2.nextLine();

        kmnalitr=kilometry / litry;
        System.out.println(kmnalitr);
    }
}
