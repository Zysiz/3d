import java.util.Scanner;

public class qsdfgbnm {
    public static void main(String[] args) {
        double detail,marsza,zysk;

        Scanner klawiatura = new Scanner(System.in);
        System.out.println("cena detaliczna ");
        detail= klawiatura.nextInt();
        klawiatura.nextLine();
        marsza=0.4;
        zysk=detail*marsza;
        System.out.println(zysk);
    }
        }
