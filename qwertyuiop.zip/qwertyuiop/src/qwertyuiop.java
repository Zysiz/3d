public class qwertyuiop {
    public static void main(String[] args) {
        double pay;
        int age;
        String name = "MC";
        age = 17;
        pay = 100001.0;

    }
}
