import java.util.Scanner;

public class sdfghjk {
    public static void main(String[] args) {
        double test1,test2,test3,srednia;
        Scanner klawiatura = new Scanner(System.in);
        System.out.println("wynik testu ");
        test1 = klawiatura.nextInt();
        klawiatura.nextLine();

        Scanner klawiatura2 = new Scanner(System.in);
        System.out.println("wynik testu ");
        test2 = klawiatura2.nextInt();
        klawiatura2.nextLine();

        Scanner klawiatura3 = new Scanner(System.in);
        System.out.println("wynik testu ");
        test3 = klawiatura3.nextInt();
        klawiatura3.nextLine();

        System.out.println(test1);
        System.out.println(test2);
        System.out.println(test3);
        srednia=(test1+test2+test3)/3;
        System.out.println(srednia);
    }
}
