public class tgb {
    public static void main(String[] args) {

    }
}
